# this script is for easying theme development :P

#alareunat
cp bottom-active.xpm bottom-inactive.xpm
cp left-active.xpm left-inactive.xpm
cp right-active.xpm right-inactive.xpm

#kulmat
cp bottom-left-active.xpm bottom-left-inactive.xpm
cp bottom-right-active.xpm bottom-right-inactive.xpm
cp top-right-active.xpm top-right-inactive.xpm
cp top-left-active.xpm top-left-inactive.xpm

#yläreuna
cp title-1-active.xpm title-1-inactive.xpm
cp title-1-active.xpm title-2-active.xpm
cp title-1-active.xpm title-2-inactive.xpm
cp title-1-active.xpm title-3-active.xpm
cp title-1-active.xpm title-3-inactive.xpm
cp title-1-active.xpm title-4-active.xpm
cp title-1-active.xpm title-4-inactive.xpm
cp title-1-active.xpm title-5-active.xpm
cp title-1-active.xpm title-5-inactive.xpm

#napit
cp close-active.xpm close-inactive.xpm
cp hide-active.xpm hide-inactive.xpm
cp maximize-active.xpm maximize-inactive.xpm
cp menu-active.xpm menu-inactive.xpm

cp maximize-active.xpm maximize-toggled-active.xpm
cp maximize-active.xpm maximize-toggled-inactive.xpm
cp maximize-pressed.xpm maximize-toggled-pressed.xpm

# cp menu-pressed.xpm close-pressed.xpm
# cp menu-pressed.xpm hide-pressed.xpm
# cp menu-pressed.xpm maximize-pressed.xpm
# cp menu-pressed.xpm maximize-toggled-pressed.xp
